# -*- coding: utf-8 -*-
"""画布控件：负责渲染 PIL 图像并处理触摸事件"""

import io
from kivy.uix.widget import Widget
from kivy.graphics import Rectangle, Color
from kivy.core.image import Image as CoreImage
from PIL import Image

class HuabuKuang(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # 初始化一张 800x600 的 PIL 画布
        self.pil_tu = Image.new("RGBA", (800, 600), (255, 255, 255, 255))
        self._chonghui()
        
        self.bind(size=self._gai_daxiao, pos=self._gai_daxiao)
        self.shang_ci_dian = None  # 记录上一个触摸点，用于画线

    def _chonghui(self):
        """把 PIL 图像转成 Kivy 纹理并刷新画布"""
        # 1. 把 PIL 图像存到内存 bytes 里
        buf = io.BytesIO()
        self.pil_tu.save(buf, format='png')
        buf.seek(0)
        
        # 2. 加载为 Kivy 纹理
        self.texture = CoreImage(buf, ext='png').texture
        
        # 3. 绘制到画布
        self.canvas.clear()
        with self.canvas:
            Color(1, 1, 1, 1)
            self.rect = Rectangle(texture=self.texture, pos=self.pos, size=self.size)

    def _gai_daxiao(self, *args):
        """窗口大小改变时，重绘矩形"""
        if hasattr(self, 'rect'):
            self.rect.pos = self.pos
            self.rect.size = self.size

    # ========== 触摸事件 ==========
    
    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos):
            # 把 Kivy 屏幕坐标映射到 PIL 画布坐标
            x, y = self._zuobiao_zhuanhuan(touch.x, touch.y)
            self.shang_ci_dian = (x, y)
            
            # 调用外部传入的绘制函数（由主界面注入）
            if hasattr(self, 'huizhi_huidiao'):
                self.huizhi_huidiao(x, y, x, y)
                self._chonghui()
            return True
        return super().on_touch_down(touch)

    def on_touch_move(self, touch):
        if self.collide_point(*touch.pos) and self.shang_ci_dian:
            x1, y1 = self.shang_ci_dian
            x2, y2 = self._zuobiao_zhuanhuan(touch.x, touch.y)
            
            if hasattr(self, 'huizhi_huidiao'):
                self.huizhi_huidiao(x1, y1, x2, y2)
                self._chonghui()
            
            self.shang_ci_dian = (x2, y2)
            return True
        return super().on_touch_move(touch)

    def on_touch_up(self, touch):
        self.shang_ci_dian = None
        return super().on_touch_up(touch)

    def _zuobiao_zhuanhuan(self, kx, ky):
        """把 Kivy 的屏幕坐标转换成 PIL 画布的像素坐标"""
        # Kivy 的坐标原点在左下角，PIL 在左上角，且要考虑缩放
        kuan, gao = self.pil_tu.size
        x = int((kx - self.x) / self.width * kuan)
        y = int((self.height - (ky - self.y)) / self.height * gao)
        return max(0, min(x, kuan-1)), max(0, min(y, gao-1))