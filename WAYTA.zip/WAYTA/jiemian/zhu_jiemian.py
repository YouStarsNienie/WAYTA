# -*- coding: utf-8 -*-
"""主界面：组装 Kivy 应用"""

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

from jiemian.huabu_kuang import HuabuKuang
from hexin.huabi import Huabi
from hexin.tuceng import Tuceng

class ZhuJiemian(App):
    def __init__(self, shangxiawen, **kwargs):
        super().__init__(**kwargs)
        self.ctx = shangxiawen
        self.huabi = Huabi(shangxiawen)
        self.tuceng_guanli = Tuceng(800, 600)

    def build(self):
        # 1. 整体垂直布局
        gen_buju = BoxLayout(orientation="vertical")

        # 2. 工具栏（这里先用几个按钮占位）
        gongjulan = BoxLayout(size_hint_y=0.15, spacing=5)
        gongjulan.add_widget(Button(text="画笔", on_press=self._qiehuan_huabi))
        gongjulan.add_widget(Button(text="橡皮", on_press=self._qiehuan_xiangpi))
        gongjulan.add_widget(Button(text="红色", on_press=self._gai_hongse))
        gongjulan.add_widget(Button(text="蓝色", on_press=self._gai_lanse))
        gen_buju.add_widget(gongjulan)

        # 3. 画布
        self.huabu_kuang = HuabuKuang()
        
        # 注入绘制回调：把 Kivy 的触摸事件转给画笔引擎处理
        def huizhi_huidiao(x1, y1, x2, y2):
            tu = self.tuceng_guanli.huizhi_dao_tuceng()
            if tu is None:
                return
            if x1 == x2 and y1 == y2:
                self.huabi.huadian(tu, x1, y1)
            else:
                self.huabi.huaxian(tu, x1, y1, x2, y2)
            
            # 把图层合成后的图更新给画布控件
            self.huabu_kuang.pil_tu = self.tuceng_guanli.hecheng()

        self.huabu_kuang.huizhi_huidiao = huizhi_huidiao
        gen_buju.add_widget(self.huabu_kuang)

        return gen_buju

    def _qiehuan_huabi(self, *args):
        self.huabi.qiehuan_moshi("huabi")

    def _qiehuan_xiangpi(self, *args):
        self.huabi.qiehuan_moshi("xiangpi")

    def _gai_hongse(self, *args):
        self.huabi.gai_yanse((255, 0, 0, 255))

    def _gai_lanse(self, *args):
        self.huabi.gai_yanse((0, 0, 255, 255))