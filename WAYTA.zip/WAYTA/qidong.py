#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WAYTA 主启动器
流程：自定位 → 读配置 → 解析路径 → 加载插件 → 启动界面
"""

import sys, os
sys.path.insert(0, "/storage/emulated/0/WAYTA")  # 强行兜底指向真实目录
os.chdir("/storage/emulated/0/WAYTA")

import sys
import os

_ZHEGE = os.path.abspath(__file__)
_GEN = os.path.dirname(_ZHEGE)
if _GEN not in sys.path:
    sys.path.insert(0, _GEN)

from gongju.lujing_suo import LujingSuo
from gongju.peizhi_du import PeizhiDu
from gongju.chajian_zai import ChajianZai


def zhixing():
    print("=" * 52)
    print("  WAYTA 绘图工作台  ·  启动中")
    print("=" * 52)

    # 1. 路径自定位
    lujing = LujingSuo(_GEN)
    print(f"[启动] 根目录   : {lujing.gen}")

    # 2. 读取 peizhi/ 下所有 txt
    peizhi = PeizhiDu(lujing.peizhi_dir)
    peizhi.duqu_quanbu()
    print(f"[启动] 已读配置 : {list(peizhi.suoyou.keys())}")

    # 3. 解析 lujing.txt 覆盖默认路径
    lujing.jiexi_lujing_peizhi(peizhi)
    lujing.chuangjian_mulu()
    print(f"[启动] 输出目录 : {lujing.shuchu_dir}")

    # 4. 组装上下文（贯穿全应用）
    shangxiawen = {
        "gen": _GEN,
        "peizhi": peizhi,
        "lujing": lujing,
        "chajian": {},
    }

    # 5. 加载插件
    zai = ChajianZai(lujing.chajian_dir, peizhi)
    shangxiawen["chajian"] = zai.faxian_bing_jiazai(shangxiawen)
    print(f"[启动] 已加载插件: {list(shangxiawen['chajian'].keys())}")

    # 6. 启动界面（无 Kivy 时降级为纯逻辑模式）
    try:
        from jiemian.zhu_jiemian import ZhuJiemian
        print("[启动] 正在启动 Kivy 界面...")
    ZhuJiemian(shangxiawen).run()
    except ImportError as e:
        print(f"[提示] Kivy 未安装 ({e})，进入纯逻辑模式")
        print("[提示] 若在手机上测试，请确保使用 PC 或 Buildozer 打包")
    except Exception as e:
        print(f"[界面] 运行异常: {e}")
    
        return shangxiawen


if __name__ == "__main__":
    zhixing()