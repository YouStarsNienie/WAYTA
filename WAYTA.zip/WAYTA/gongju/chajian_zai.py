# -*- coding: utf-8 -*-
"""插件加载器：扫描 chajian/，按 peizhi/chajian.txt 开关与顺序加载"""

import os
import importlib.util


class ChajianZai:
    def __init__(self, chajian_dir, peizhi_du):
        self.chajian_dir = chajian_dir
        self.peizhi = peizhi_du
        self.yijiazai = {}

    def faxian_bing_jiazai(self, shangxiawen):
        if not os.path.isdir(self.chajian_dir):
            return self.yijiazai
        kaiguan = self._du_kaiguan()
        shunxu  = self._du_shunxu()

        wjs = [f for f in os.listdir(self.chajian_dir)
               if f.endswith(".py") and f != "__init__.py"]
        wjs.sort(key=lambda f: shunxu.get(f[:-3], 999))

        for wj in wjs:
            ming = wj[:-3]
            if ming in kaiguan and not kaiguan[ming]:
                print(f"[插件] 跳过 {ming} (配置为关)")
                continue
            try:
                obj = self._jiazai(wj, shangxiawen)
                if obj is not None:
                    self.yijiazai[ming] = obj
            except Exception as e:
                print(f"[插件] {wj} 加载失败: {e}")
        return self.yijiazai

    def _du_kaiguan(self):
        out = {}
        q = self.peizhi.suoyou.get("chajian")
        if q and q.has_section("kaiguan"):
            for k in q.options("kaiguan"):
                out[k] = q.getboolean("kaiguan", k)
        return out

    def _du_shunxu(self):
        out = {}
        q = self.peizhi.suoyou.get("chajian")
        if q and q.has_section("shunxu"):
            for k in q.options("shunxu"):
                try: out[k] = int(q.get("shunxu", k))
                except ValueError: pass
        return out

    def _jiazai(self, wj, shangxiawen):
        lujing = os.path.join(self.chajian_dir, wj)
        ming = wj[:-3]
        spec = importlib.util.spec_from_file_location(ming, lujing)
        if not spec or not spec.loader:
            return None
        mb = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mb)
        # 插件需暴露 zhuce(shangxiawen)
        if hasattr(mb, "zhuce"):
            return mb.zhuce(shangxiawen)
        return mb