# -*- coding: utf-8 -*-
"""配置读取器：统一把 peizhi/*.txt 变成 Python 可查询对象"""

import os
import configparser


class PeizhiDu:
    def __init__(self, peizhi_dir):
        self.peizhi_dir = peizhi_dir
        self.suoyou = {}

    def duqu_quanbu(self):
        if not os.path.isdir(self.peizhi_dir):
            print(f"[配置] 目录不存在: {self.peizhi_dir}")
            return self.suoyou
        for wj in sorted(os.listdir(self.peizhi_dir)):
            if not wj.endswith(".txt"):
                continue
            ming = wj[:-4]
            qu = configparser.ConfigParser()
            try:
                qu.read(os.path.join(self.peizhi_dir, wj), encoding="utf-8")
                self.suoyou[ming] = qu
            except Exception as e:
                print(f"[配置] {wj} 读取失败: {e}")
        return self.suoyou

    def qu(self, m, j, k, moren=None):
        q = self.suoyou.get(m)
        return q.get(j, k, fallback=moren) if q else moren

    def qu_zhengshu(self, m, j, k, moren=0):
        try:    return int(self.qu(m, j, k))
        except: return moren

    def qu_fudian(self, m, j, k, moren=0.0):
        try:    return float(self.qu(m, j, k))
        except: return moren

    def qu_buer(self, m, j, k, moren=False):
        v = self.qu(m, j, k)
        if v is None: return moren
        return v.strip().lower() in ("true", "1", "yes", "shi", "kai")

    def qu_yanse(self, m, j, k, moren=(0,0,0,255)):
        v = self.qu(m, j, k)
        if not v: return moren
        try:
            p = [int(x.strip()) for x in v.split(",")]
            if len(p) == 3: return tuple(p) + (255,)
            if len(p) == 4: return tuple(p)
        except ValueError:
            pass
        return moren