# -*- coding: utf-8 -*-
"""路径解析器：自定位 + 路径配置覆盖 + 目录创建 + 缓存清理"""

import os
import shutil


class LujingSuo:
    def __init__(self, gen):
        self.gen = gen
        self.peizhi_dir = os.path.join(gen, "peizhi")
        self.hexin_dir  = os.path.join(gen, "hexin")
        self.jiemian_dir= os.path.join(gen, "jiemian")
        self.chajian_dir= os.path.join(gen, "chajian")
        self.gongju_dir = os.path.join(gen, "gongju")
        self.ziyuan_dir = os.path.join(gen, "ziyuan")
        self.shuchu_dir = os.path.join(gen, "shuchu")
        self.huancun_dir= os.path.join(gen, ".huancun")
        self.waibu_dir  = "/storage/emulated/0"

    def jiexi_lujing_peizhi(self, peizhi):
        qu = peizhi.suoyou.get("lujing")
        if not qu:
            return
        def _q(jian, moren):
            v = qu.get("lujing", jian, fallback=moren)
            return v.replace("{gen}", self.gen) if v else moren
        self.shuchu_dir = _q("shuchu_dir", self.shuchu_dir)
        self.huancun_dir= _q("huancun_dir", self.huancun_dir)
        self.waibu_dir  = _q("waibu_dir",   self.waibu_dir)

    def chuangjian_mulu(self):
        for d in (self.shuchu_dir, self.huancun_dir, self.ziyuan_dir):
            try:
                os.makedirs(d, exist_ok=True)
            except OSError as e:
                print(f"[路径] 创建失败 {d}: {e}")

    def qingli_huancun(self):
        if os.path.exists(self.huancun_dir):
            shutil.rmtree(self.huancun_dir)
        os.makedirs(self.huancun_dir, exist_ok=True)
        return True