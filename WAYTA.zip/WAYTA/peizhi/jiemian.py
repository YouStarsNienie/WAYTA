[buju]
gongjulan_gaodu = 60
mianban_kuandu = 240
zhuti_yanse = 40,44,52,255
qiangdiao_yanse = 88,166,255,255