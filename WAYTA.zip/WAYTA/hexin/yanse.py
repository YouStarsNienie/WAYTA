# -*- coding: utf-8 -*-
"""颜色系统：RGB / HSV / HEX 互转，图像亮度/透明度/颜色调整"""

import colorsys
from PIL import Image, ImageEnhance

class Yanse:
    
    # ========== 颜色格式转换 ==========
    
    @staticmethod
    def rgb_zhuan_hex(r, g, b):
        """RGB -> 十六进制字符串 (#FF0000)"""
        return f"#{int(r):02X}{int(g):02X}{int(b):02X}"
    
    @staticmethod
    def hex_zhuan_rgb(hex_str):
        """十六进制字符串 -> RGB 元组 (255, 0, 0)"""
        hex_str = hex_str.lstrip('#')
        if len(hex_str) == 3:  # 支持 #F00 简写
            hex_str = ''.join([c*2 for c in hex_str])
        return tuple(int(hex_str[i:i+2], 16) for i in (0, 2, 4))
    
    @staticmethod
    def rgb_zhuan_hsv(r, g, b):
        """RGB -> HSV，H: 0-360, S: 0-100, V: 0-100"""
        h, s, v = colorsys.rgb_to_hsv(r/255.0, g/255.0, b/255.0)
        return round(h * 360, 1), round(s * 100, 1), round(v * 100, 1)
    
    @staticmethod
    def hsv_zhuan_rgb(h, s, v):
        """HSV -> RGB，输入 H: 0-360, S: 0-100, V: 0-100"""
        r, g, b = colorsys.hsv_to_rgb(h/360.0, s/100.0, v/100.0)
        return int(r*255), int(g*255), int(b*255)

    # ========== 图像级别的颜色/亮度/透明度调整 ==========
    
    @staticmethod
    def tiaozheng_liangdu(tuxiang, xishu):
        """调整图像亮度：xishu > 1.0 变亮，< 1.0 变暗"""
        return ImageEnhance.Brightness(tuxiang).enhance(xishu)
    
    @staticmethod
    def tiaozheng_duibidu(tuxiang, xishu):
        """调整图像对比度：xishu > 1.0 增强，< 1.0 减弱"""
        return ImageEnhance.Contrast(tuxiang).enhance(xishu)
    
    @staticmethod
    def tiaozheng_baohedu(tuxiang, xishu):
        """调整图像色彩饱和度：xishu > 1.0 更鲜艳，< 1.0 更灰暗"""
        return ImageEnhance.Color(tuxiang).enhance(xishu)
    
    @staticmethod
    def tiaozheng_toumingdu(tuxiang, alpha_0_255):
        """整体调整图像透明度（0 全透明，255 不透明）"""
        if tuxiang.mode != "RGBA":
            tuxiang = tuxiang.convert("RGBA")
        alpha = tuxiang.split()[3]
        alpha = alpha.point(lambda p: int(p * (alpha_0_255 / 255.0)))
        tuxiang.putalpha(alpha)
        return tuxiang

    @staticmethod
    def qu_tuxiang_yanse(tuxiang, x, y):
        """取色器：获取图像 (x, y) 处的 RGB 与 HSV"""
        if tuxiang.mode != "RGBA":
            tuxiang = tuxiang.convert("RGBA")
        r, g, b, a = tuxiang.getpixel((x, y))
        h, s, v = Yanse.rgb_zhuan_hsv(r, g, b)
        return {
            "rgb": (r, g, b),
            "rgba": (r, g, b, a),
            "hsv": (h, s, v),
            "hex": Yanse.rgb_zhuan_hex(r, g, b)
        }

    @staticmethod
    def gai_tuxiang_yanse(tuxiang, r, g, b, qiangdu=1.0):
        """给图像叠一层颜色（qiangdu: 0.0-1.0），类似给图片加滤镜"""
        if tuxiang.mode != "RGBA":
            tuxiang = tuxiang.convert("RGBA")
        fuceng = Image.new("RGBA", tuxiang.size, (r, g, b, int(255 * qiangdu)))
        return Image.alpha_composite(tuxiang, fuceng)