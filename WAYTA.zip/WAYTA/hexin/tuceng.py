# -*- coding: utf-8 -*-
"""图层引擎：图层栈的增删改查、显隐、排序、透明度、合并"""

from PIL import Image, ImageChops

class Tuceng:
    def __init__(self, kuan, gao, zuida_tuceng=32):
        self.kuan = kuan
        self.gao = gao
        self.zuida = zuida_tuceng
        self.tuceng_liebiao = []
        self.dangqian_suoyin = -1
        self._chuangjian_moren_tuceng()

    def _chuangjian_moren_tuceng(self):
        """初始化时创建一个默认的透明图层"""
        self.tianjia_tuceng("Tuceng_1")

    def tianjia_tuceng(self, mingcheng=None):
        if len(self.tuceng_liebiao) >= self.zuida:
            print(f"[图层] 已达上限 {self.zuida} 层，无法添加")
            return False
        
        # 新图层默认全透明
        xin_tu = Image.new("RGBA", (self.kuan, self.gao), (0, 0, 0, 0))
        ming = mingcheng or f"Tuceng_{len(self.tuceng_liebiao)+1}"
        
        ceng = {
            "ming": ming,
            "tu": xin_tu,
            "xianshi": True,
            "touming_du": 255,  # 0-255
            "hunhe_moshi": "normal"
        }
        self.tuceng_liebiao.append(ceng)
        self.dangqian_suoyin = len(self.tuceng_liebiao) - 1
        print(f"[图层] 已添加: {ming}")
        return True

    def shanchu_tuceng(self, suoyin=None):
        if len(self.tuceng_liebiao) <= 1:
            print("[图层] 至少保留一层，无法删除")
            return False
        idx = suoyin if suoyin is not None else self.dangqian_suoyin
        if 0 <= idx < len(self.tuceng_liebiao):
            ming = self.tuceng_liebiao[idx]["ming"]
            del self.tuceng_liebiao[idx]
            self.dangqian_suoyin = max(0, len(self.tuceng_liebiao) - 1)
            print(f"[图层] 已删除: {ming}")
            return True
        return False

    def xuanze_tuceng(self, suoyin):
        if 0 <= suoyin < len(self.tuceng_liebiao):
            self.dangqian_suoyin = suoyin
            return True
        return False

    def qiehuan_xianshi(self, suoyin):
        if 0 <= suoyin < len(self.tuceng_liebiao):
            ceng = self.tuceng_liebiao[suoyin]
            ceng["xianshi"] = not ceng["xianshi"]
            print(f"[图层] {ceng['ming']} 显隐: {ceng['xianshi']}")
            return ceng["xianshi"]
        return None

    def she_touming_du(self, touming_du, suoyin=None):
        idx = suoyin if suoyin is not None else self.dangqian_suoyin
        if 0 <= idx < len(self.tuceng_liebiao):
            self.tuceng_liebiao[idx]["touming_du"] = max(0, min(255, touming_du))

    def yidong_cengji(self, yuan_idx, xin_idx):
        """调整图层顺序（如置顶、置底）"""
        if 0 <= yuan_idx < len(self.tuceng_liebiao) and 0 <= xin_idx < len(self.tuceng_liebiao):
            ceng = self.tuceng_liebiao.pop(yuan_idx)
            self.tuceng_liebiao.insert(xin_idx, ceng)
            self.dangqian_suoyin = xin_idx
            return True
        return False

    def hecheng(self):
        """将所有可见图层按透明度混合成一张最终图"""
        if not self.tuceng_liebiao:
            return Image.new("RGBA", (self.kuan, self.gao), (255, 255, 255, 255))
        
        jieguo = Image.new("RGBA", (self.kuan, self.gao), (0, 0, 0, 0))
        
        for ceng in self.tuceng_liebiao:
            if not ceng["xianshi"]:
                continue
            
            tu = ceng["tu"]
            if ceng["touming_du"] < 255:
                # 调节图层整体透明度
                alpha = tu.split()[3]
                alpha = alpha.point(lambda p: int(p * (ceng["touming_du"] / 255)))
                tu = tu.copy()
                tu.putalpha(alpha)
            
            jieguo = Image.alpha_composite(jieguo, tu)
        
        return jieguo

    def huizhi_dao_tuceng(self, suoyin=None):
        """获取当前图层供画笔引擎使用"""
        idx = suoyin if suoyin is not None else self.dangqian_suoyin
        if 0 <= idx < len(self.tuceng_liebiao):
            return self.tuceng_liebiao[idx]["tu"]
        return None

    def liechu(self):
        """列出所有图层信息，方便UI面板显示"""
        for i, ceng in enumerate(self.tuceng_liebiao):
            zhuangtai = "开" if ceng["xianshi"] else "关"
            dangqian = " ◀" if i == self.dangqian_suoyin else ""
            print(f"  [{i}] {ceng['ming']} | 显隐:{zhuangtai} | 透明度:{ceng['touming_du']}{dangqian}")