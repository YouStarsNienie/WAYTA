# -*- coding: utf-8 -*-
"""画笔引擎：点/线/几何图形/填充/橡皮擦"""

from PIL import Image, ImageDraw

class Huabi:
    def __init__(self, shangxiawen):
        self.ctx = shangxiawen
        p = shangxiawen["peizhi"]
        # 从 peizhi/huabi.txt 读取默认参数
        self.moren_daxiao = p.qu_zhengshu("huabi", "huabi", "moren_daxiao", 5)
        self.moren_yanse = p.qu_yanse("huabi", "huabi", "moren_yanse", (0, 0, 0, 255))
        self.yingdu = p.qu_fudian("huabi", "huabi", "yingdu", 1.0)
        
        # 当前状态
        self.dangqian_daxiao = self.moren_daxiao
        self.dangqian_yanse = self.moren_yanse
        self.moshi = "huabi"  # huabi(画笔) / xiangpi(橡皮擦) / tianchong(填充)

    def gai_daxiao(self, daxiao):
        self.dangqian_daxiao = max(1, int(daxiao))

    def gai_yanse(self, yanse):
        self.dangqian_yanse = yanse

    def qiehuan_moshi(self, moshi):
        """切换画笔模式：huabi / xiangpi / tianchong"""
        if moshi in ("huabi", "xiangpi", "tianchong"):
            self.moshi = moshi

    # ========== 基础绘制 ==========
    
    def huadian(self, tuxiang, x, y):
        """画点（圆点）"""
        hua = ImageDraw.Draw(tuxiang)
        banjing = self.dangqian_daxiao // 2
        if self.moshi == "xiangpi":
            # 橡皮擦：画透明
            hua.ellipse([x-banjing, y-banjing, x+banjing, y+banjing], fill=(0,0,0,0))
        else:
            hua.ellipse([x-banjing, y-banjing, x+banjing, y+banjing], fill=self.dangqian_yanse)

    def huaxian(self, tuxiang, x1, y1, x2, y2):
        """画线（用于连续绘画）"""
        hua = ImageDraw.Draw(tuxiang)
        if self.moshi == "xiangpi":
            hua.line([x1, y1, x2, y2], fill=(0,0,0,0), width=self.dangqian_daxiao)
        else:
            hua.line([x1, y1, x2, y2], fill=self.dangqian_yanse, width=self.dangqian_daxiao)

    # ========== 几何图形 ==========
    
    def hua_juxing(self, tuxiang, x1, y1, x2, y2, tianchong=False):
        """画矩形，tianchong=True 时填充"""
        hua = ImageDraw.Draw(tuxiang)
        box = [min(x1,x2), min(y1,y2), max(x1,x2), max(y1,y2)]
        if tianchong:
            hua.rectangle(box, fill=self.dangqian_yanse)
        else:
            hua.rectangle(box, outline=self.dangqian_yanse, width=self.dangqian_daxiao)

    def hua_yuan(self, tuxiang, x, y, banjing, tianchong=False):
        """画圆"""
        hua = ImageDraw.Draw(tuxiang)
        box = [x-banjing, y-banjing, x+banjing, y+banjing]
        if tianchong:
            hua.ellipse(box, fill=self.dangqian_yanse)
        else:
            hua.ellipse(box, outline=self.dangqian_yanse, width=self.dangqian_daxiao)

    def hua_tuoyuan(self, tuxiang, x1, y1, x2, y2, tianchong=False):
        """画椭圆"""
        hua = ImageDraw.Draw(tuxiang)
        box = [min(x1,x2), min(y1,y2), max(x1,x2), max(y1,y2)]
        if tianchong:
            hua.ellipse(box, fill=self.dangqian_yanse)
        else:
            hua.ellipse(box, outline=self.dangqian_yanse, width=self.dangqian_daxiao)

    # ========== 填充 ==========
    
    def tianchong(self, tuxiang, x, y):
        """油漆桶：在 (x, y) 处进行颜色填充"""
        # PIL 自带的 floodfill 要求颜色匹配，对于抗锯齿图像可能不完美，但够用
        ImageDraw.floodfill(tuxiang, (x, y), self.dangqian_yanse, thresh=30)

    # ========== 取色 ==========
    
    def qu_se(self, tuxiang, x, y):
        """取色器：获取 (x, y) 处的颜色"""
        if tuxiang.mode != "RGBA":
            tuxiang = tuxiang.convert("RGBA")
        # 防止越界
        k, g = tuxiang.size
        x = max(0, min(x, k-1))
        y = max(0, min(y, g-1))
        return tuxiang.getpixel((x, y))

def zhuce(shangxiawen):
    return Huabi(shangxiawen)