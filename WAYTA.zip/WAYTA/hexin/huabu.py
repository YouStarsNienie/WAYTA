# -*- coding: utf-8 -*-
"""画布引擎：尺寸/缩放/旋转/镜像/扩展/压缩/导入导出"""

import os
from PIL import Image


class Huabu:
    def __init__(self, kuan=1920, gao=1080, beijing=(255,255,255,255)):
        self.kuan = kuan
        self.gao = gao
        self.beijing_yanse = beijing
        self.tuxiang = Image.new("RGBA", (kuan, gao), beijing)
        self.suofang = 1.0
        self.pingyi = [0, 0]
        self.xuanzhuan_jiao = 0

    @classmethod
    def cong_peizhi(cls, peizhi):
        return cls(
            peizhi.qu_zhengshu("huabu", "huabu", "moren_kuan", 1920),
            peizhi.qu_zhengshu("huabu", "huabu", "moren_gao", 1080),
            peizhi.qu_yanse("huabu", "huabu", "beijing_yanse", (255,255,255,255)),
        )

    def gai_daxiao(self, xin_kuan, xin_gao, baoliu=True):
        if baoliu:
            xin = Image.new("RGBA", (xin_kuan, xin_gao), self.beijing_yanse)
            xin.paste(self.tuxiang,
                      ((xin_kuan-self.kuan)//2, (xin_gao-self.gao)//2),
                      self.tuxiang)
            self.tuxiang = xin
        else:
            self.tuxiang = Image.new("RGBA", (xin_kuan, xin_gao), self.beijing_yanse)
        self.kuan, self.gao = xin_kuan, xin_gao

    def kuozhan(self, zuo, shang, you, xia, tianchong=None):
        tc = tianchong or self.beijing_yanse
        nk, ng = self.kuan+zuo+you, self.gao+shang+xia
        xin = Image.new("RGBA", (nk, ng), tc)
        xin.paste(self.tuxiang, (zuo, shang), self.tuxiang)
        self.tuxiang = xin
        self.kuan, self.gao = nk, ng

    def yasuo(self, zuo, shang, you, xia):
        box = (zuo, shang, self.kuan-you, self.gao-xia)
        self.tuxiang = self.tuxiang.crop(box)
        self.kuan, self.gao = self.tuxiang.size

    def xuanzhuan(self, jiaodu, kuozhan=True):
        self.tuxiang = self.tuxiang.rotate(jiaodu, expand=kuozhan)
        self.kuan, self.gao = self.tuxiang.size
        self.xuanzhuan_jiao = (self.xuanzhuan_jiao + jiaodu) % 360

    def jingxiang(self, fangxiang="shui"):
        if fangxiang in ("shui", "shuang"):
            self.tuxiang = self.tuxiang.transpose(Image.FLIP_LEFT_RIGHT)
        if fangxiang in ("chui", "shuang"):
            self.tuxiang = self.tuxiang.transpose(Image.FLIP_TOP_BOTTOM)

    def suofang(self, bilie=None, xin_kuan=None, xin_gao=None):
        if bilie is not None:
            xin_kuan = int(self.kuan * bilie)
            xin_gao  = int(self.gao  * bilie)
        if xin_kuan and xin_gao:
            self.tuxiang = self.tuxiang.resize((xin_kuan, xin_gao), Image.LANCZOS)
            self.kuan, self.gao = xin_kuan, xin_gao

    def daochu(self, lujing, geshi="PNG"):
        os.makedirs(os.path.dirname(lujing), exist_ok=True)
        self.tuxiang.save(lujing, geshi)
        return lujing

    def daoru(self, lujing):
        self.tuxiang = Image.open(lujing).convert("RGBA")
        self.kuan, self.gao = self.tuxiang.size
        return self