# -*- coding: utf-8 -*-
"""选区引擎：矩形/套索/复制/剪切/粘贴/清空/填充"""

from PIL import Image, ImageDraw

class Xuanqu:
    def __init__(self, kuan, gao):
        self.kuan = kuan
        self.gao = gao
        self.mask = Image.new("L", (kuan, gao), 0)  # 0=未选，255=选中
        self.zhandouban = None  # 剪贴板
        self.xuanqu_kuang = (0, 0, 0, 0)  # 记录选区边界

    # ========== 建立选区 ==========
    def shezhi_juxing(self, x1, y1, x2, y2):
        """矩形选区：自动纠正拖拽方向"""
        self.mask = Image.new("L", (self.kuan, self.gao), 0)
        hua = ImageDraw.Draw(self.mask)
        # 保证左上角永远是起点
        box = [min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)]
        hua.rectangle(box, fill=255)
        self.xuanqu_kuang = tuple(box)
        return box

    def shezhi_taosuo(self, dian_liebiao):
        """多边形/套索选区：传入坐标点列表 [(x1,y1), (x2,y2), ...]"""
        if len(dian_liebiao) < 3:
            return False
        self.mask = Image.new("L", (self.kuan, self.gao), 0)
        hua = ImageDraw.Draw(self.mask)
        hua.polygon(dian_liebiao, fill=255)
        self.xuanqu_kuang = self.mask.getbbox()
        return True

    def quxiao_xuanqu(self):
        """取消选区（全黑）"""
        self.mask = Image.new("L", (self.kuan, self.gao), 0)
        self.xuanqu_kuang = (0, 0, 0, 0)

    # ========== 复制 / 剪切 ==========
    def fuzhi(self, tuxiang):
        """复制选区内容到剪贴板"""
        self.zhandouban = tuxiang.copy()
        # 利用蒙版把选区外变成透明的
        self.zhandouban.putalpha(self.mask)
        return self.zhandouban

    def jianqie(self, tuxiang):
        """剪切：先复制，再把原图选区部分挖空"""
        fuzhi_de = self.fuzhi(tuxiang)
        touming = Image.new("RGBA", tuxiang.size, (0, 0, 0, 0))
        tuxiang.paste(touming, (0, 0), self.mask)
        return fuzhi_de

    # ========== 粘贴 ==========
    def zhantie(self, mubiao_tuxiang, x, y):
        """把剪贴板内容贴到目标图像的 (x, y) 处"""
        if self.zhandouban is None:
            return False
        mubiao_tuxiang.paste(self.zhandouban, (x, y), self.zhandouban)
        return True

    # ========== 选区内操作 ==========
    def qingkong(self, tuxiang):
        """清空（删除）选区内像素"""
        touming = Image.new("RGBA", tuxiang.size, (0, 0, 0, 0))
        tuxiang.paste(touming, (0, 0), self.mask)

    def tianchong(self, tuxiang, yanse):
        """用指定颜色填充选区"""
        fuceng = Image.new("RGBA", tuxiang.size, yanse)
        # 只在 mask 为 255 的地方粘贴
        tuxiang.paste(fuceng, (0, 0), self.mask)

    def daochu_mask(self, lujing):
        """导出一张灰度蒙版图，用于调试"""
        self.mask.save(lujing)