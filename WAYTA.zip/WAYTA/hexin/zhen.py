# -*- coding: utf-8 -*-
"""帧动画引擎：帧的增删改查、播放、反转、导出 GIF"""

import os
from PIL import Image
from hexin.tuceng import Tuceng

class Zhen:
    def __init__(self, kuan, gao, shangxiawen):
        self.ctx = shangxiawen
        p = shangxiawen["peizhi"]
        self.kuan = kuan
        self.gao = gao
        
        # 从 peizhi/zhen.txt 读取参数
        self.zhenlv = p.qu_zhengshu("zhen", "zhen", "moren_zhenlv", 12)
        self.zuida_zhen = p.qu_zhengshu("zhen", "zhen", "zuida_zhen", 64)
        self.xunhuan = p.qu_buer("zhen", "zhen", "xunhuan", True)
        
        # 帧列表：每个元素是一个 Tuceng 实例
        self.zhen_liebiao = []
        self.dangqian_suoyin = 0
        self._chuangjian_moren()

    def _chuangjian_moren(self):
        """初始化时创建第一帧"""
        tc = Tuceng(self.kuan, self.gao)
        self.zhen_liebiao.append(tc)
        self.dangqian_suoyin = 0

    # ========== 帧管理 ==========
    
    def tianjia_zhen(self, fuzhi=False):
        """添加新帧：fuzhi=True 时复制当前帧，False 时新建空白帧"""
        if len(self.zhen_liebiao) >= self.zuida_zhen:
            print(f"[帧] 已达上限 {self.zuida_zhen} 帧，无法添加")
            return False
        
        if fuzhi:
            # 复制当前帧的图层栈
            dangqian_tc = self.zhen_liebiao[self.dangqian_suoyin]
            xin_tc = Tuceng(self.kuan, self.gao)
            xin_tc.tuceng_liebiao = []
            for ceng in dangqian_tc.tuceng_liebiao:
                xin_ceng = {
                    "ming": ceng["ming"],
                    "tu": ceng["tu"].copy(),
                    "xianshi": ceng["xianshi"],
                    "touming_du": ceng["touming_du"],
                    "hunhe_moshi": ceng["hunhe_moshi"]
                }
                xin_tc.tuceng_liebiao.append(xin_ceng)
        else:
            xin_tc = Tuceng(self.kuan, self.gao)
        
        self.zhen_liebiao.append(xin_tc)
        self.dangqian_suoyin = len(self.zhen_liebiao) - 1
        print(f"[帧] 已添加: 第 {len(self.zhen_liebiao)} 帧")
        return True

    def shanchu_zhen(self, suoyin=None):
        """删除帧"""
        if len(self.zhen_liebiao) <= 1:
            print("[帧] 至少保留一帧，无法删除")
            return False
        idx = suoyin if suoyin is not None else self.dangqian_suoyin
        if 0 <= idx < len(self.zhen_liebiao):
            del self.zhen_liebiao[idx]
            self.dangqian_suoyin = max(0, len(self.zhen_liebiao) - 1)
            print(f"[帧] 已删除第 {idx} 帧")
            return True
        return False

    def qiehuan_zhen(self, suoyin):
        """切换当前帧"""
        if 0 <= suoyin < len(self.zhen_liebiao):
            self.dangqian_suoyin = suoyin
            return True
        return False

    def yidong_zhen(self, yuan_idx, xin_idx):
        """调整帧顺序"""
        if 0 <= yuan_idx < len(self.zhen_liebiao) and 0 <= xin_idx < len(self.zhen_liebiao):
            zhen = self.zhen_liebiao.pop(yuan_idx)
            self.zhen_liebiao.insert(xin_idx, zhen)
            self.dangqian_suoyin = xin_idx
            return True
        return False

    def fanzhuan(self):
        """反转帧顺序（倒放）"""
        self.zhen_liebiao.reverse()
        self.dangqian_suoyin = len(self.zhen_liebiao) - 1 - self.dangqian_suoyin
        print("[帧] 已反转")

    def shezhi_zhenlv(self, xin_zhenlv):
        self.zhenlv = max(1, int(xin_zhenlv))

    # ========== 渲染与导出 ==========
    
    def huoqu_dangqian_tu(self):
        """获取当前帧合成后的图像"""
        return self.zhen_liebiao[self.dangqian_suoyin].hecheng()

    def daochu_gif(self, lujing):
        """导出为 GIF 动画"""
        if not self.zhen_liebiao:
            return False
        tubiao = []
        for tc in self.zhen_liebiao:
            tu = tc.hecheng()
            tubiao.append(tu.convert("RGB"))  # GIF 不支持 RGBA
        
        # 第一帧作为主图
        tubiao[0].save(
            lujing,
            save_all=True,
            append_images=tubiao[1:],
            duration=int(1000 / self.zhenlv),  # 每帧毫秒数
            loop=0 if self.xunhuan else 1
        )
        print(f"[帧] 已导出 GIF: {lujing}")
        return True

    def liechu(self):
        """列出所有帧信息"""
        for i, tc in enumerate(self.zhen_liebiao):
            zhuangtai = " ◀" if i == self.dangqian_suoyin else ""
            print(f"  第 {i} 帧 | 图层数: {len(tc.tuceng_liebiao)}{zhuangtai}")