# -*- coding: utf-8 -*-
"""图像变换引擎：缩放/旋转/多方向镜像/画布扩展/压缩/改变宽高比"""

from PIL import Image

class Bianhuan:
    
    # ========== 缩放 ==========
    @staticmethod
    def suofang_an_bilie(tuxiang, bilie):
        """按比例缩放：bilie=0.5 缩小一半，2.0 放大一倍"""
        k, g = tuxiang.size
        xin_k = max(1, int(k * bilie))
        xin_g = max(1, int(g * bilie))
        return tuxiang.resize((xin_k, xin_g), Image.LANCZOS)
    
    @staticmethod
    def suofang_zidingyi(tuxiang, xin_kuan, xin_gao):
        """自定义长宽比缩放：拉伸/压缩到指定的宽高"""
        return tuxiang.resize((xin_kuan, xin_gao), Image.LANCZOS)
    
    # ========== 旋转 ==========
    @staticmethod
    def xuanzhuan(tuxiang, jiaodu, kuozhan=True):
        """旋转图像，kuozhan=True 时自动扩大画布以容纳旋转后的图像"""
        return tuxiang.rotate(jiaodu, expand=kuozhan, resample=Image.BICUBIC)
    
    # ========== 多方向镜像 ==========
    @staticmethod
    def jingxiang(tuxiang, fangxiang="shui"):
        """镜像：shui=水平，chui=垂直，shuang=双向"""
        if fangxiang == "shui":
            return tuxiang.transpose(Image.FLIP_LEFT_RIGHT)
        elif fangxiang == "chui":
            return tuxiang.transpose(Image.FLIP_TOP_BOTTOM)
        elif fangxiang == "shuang":
            jieguo = tuxiang.transpose(Image.FLIP_LEFT_RIGHT)
            return jieguo.transpose(Image.FLIP_TOP_BOTTOM)
        return tuxiang
    
    # ========== 画布扩展 ==========
    @staticmethod
    def kuozhan_huabu(tuxiang, zuo, shang, you, xia, tianchong=(0, 0, 0, 0)):
        """在四周增加像素：zuo/shang/you/xia 是各边增加的像素数"""
        k, g = tuxiang.size
        xin_k = k + zuo + you
        xin_g = g + shang + xia
        xin_tu = Image.new("RGBA", (xin_k, xin_g), tianchong)
        xin_tu.paste(tuxiang, (zuo, shang), tuxiang if tuxiang.mode == "RGBA" else None)
        return xin_tu
    
    # ========== 画布压缩/裁剪 ==========
    @staticmethod
    def yasuo_huabu(tuxiang, zuo, shang, you, xia):
        """从四周裁剪掉像素，只保留中间区域"""
        k, g = tuxiang.size
        box = (zuo, shang, k - you, g - xia)
        return tuxiang.crop(box)
    
    # ========== 自定义长宽比（覆盖式） ==========
    @staticmethod
    def gai_kuan_gao(tuxiang, xin_kuan, xin_gao, baoliu=True):
        """改变画布大小，baoliu=True 时居中原图，不缩放；False 时拉伸铺满"""
        if baoliu:
            # 创建新画布，把原图居中贴上去
            xin_tu = Image.new("RGBA", (xin_kuan, xin_gao), (255, 255, 255, 255))
            k, g = tuxiang.size
            x = max(0, (xin_kuan - k) // 2)
            y = max(0, (xin_gao - g) // 2)
            xin_tu.paste(tuxiang, (x, y), tuxiang if tuxiang.mode == "RGBA" else None)
            return xin_tu
        else:
            # 直接拉伸到新尺寸
            return tuxiang.resize((xin_kuan, xin_gao), Image.LANCZOS)