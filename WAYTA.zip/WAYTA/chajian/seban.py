# -*- coding: utf-8 -*-
"""色板插件：颜色管理、导入/导出 txt 色板文件"""

import os

class Seban:
    def __init__(self, shangxiawen):
        self.ctx = shangxiawen
        self.peizhi = shangxiawen["peizhi"]
        self.yanse_liebiao = []  # 存储格式: [(255,0,0,255), (0,255,0,255), ...]
        self._jiazai_moren()

    def _jiazai_moren(self):
        """从 peizhi/seban.txt 读取默认色板"""
        # 尝试读取 [moren] 节下的 se_1, se_2 ...
        quan = self.peizhi.suoyou.get("seban")
        if quan and quan.has_section("moren"):
            for k, v in quan.items("moren"):
                try:
                    # 格式：se_1 = 255,0,0,255
                    p = [int(x.strip()) for x in v.split(",")]
                    if len(p) == 3: p.append(255)
                    self.yanse_liebiao.append(tuple(p))
                except:
                    pass
        # 如果没有配置，给几个默认色
        if not self.yanse_liebiao:
            self.yanse_liebiao = [
                (0, 0, 0, 255), (255, 255, 255, 255), 
                (255, 0, 0, 255), (0, 255, 0, 255), 
                (0, 0, 255, 255), (255, 255, 0, 255)
            ]

    def tianjia_yanse(self, yanse):
        if yanse not in self.yanse_liebiao:
            self.yanse_liebiao.append(yanse)

    def shanchu_yanse(self, suoyin):
        if 0 <= suoyin < len(self.yanse_liebiao):
            return self.yanse_liebiao.pop(suoyin)
        return None

    def daochu_txt(self, wenjian_lujing):
        """导出为 txt 文件"""
        with open(wenjian_lujing, "w", encoding="utf-8") as f:
            f.write("[seban]\n")
            for i, ys in enumerate(self.yanse_liebiao):
                f.write(f"se_{i} = {ys[0]},{ys[1]},{ys[2]},{ys[3]}\n")
        print(f"[色板] 已导出: {wenjian_lujing}")
        return True

    def daoru_txt(self, wenjian_lujing):
        """从 txt 文件导入色板"""
        if not os.path.exists(wenjian_lujing):
            return False
        with open(wenjian_lujing, "r", encoding="utf-8") as f:
            for line in f:
                if "=" in line and not line.startswith("["):
                    try:
                        p = [int(x.strip()) for x in line.split("=")[1].split(",")]
                        if len(p) == 3: p.append(255)
                        self.tianjia_yanse(tuple(p))
                    except:
                        pass
        print(f"[色板] 已导入: {wenjian_lujing}")
        return True


def zhuce(shangxiawen):
    return Seban(shangxiawen)