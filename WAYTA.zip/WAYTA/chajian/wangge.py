# -*- coding: utf-8 -*-
"""网格/坐标系插件"""


from PIL import Image, ImageDraw


class Wangge:
    def __init__(self, shangxiawen):
        p = shangxiawen["peizhi"]
        self.xianshi   = p.qu_buer("huabu", "wangge", "xianshi", True)
        self.daxiao    = p.qu_zhengshu("huabu", "wangge", "daxiao", 50)
        self.yanse     = p.qu_yanse("huabu", "wangge", "yanse", (200,200,200,128))
        self.zuobiao   = p.qu_buer("huabu", "wangge", "zuobiao", True)

    def huizhi(self, tuxiang):
        if not self.xianshi:
            return tuxiang
        ceng = Image.new("RGBA", tuxiang.size, (0,0,0,0))
        hua = ImageDraw.Draw(ceng)
        k, g = tuxiang.size
        for x in range(0, k, self.daxiao):
            hua.line([(x,0),(x,g)], fill=self.yanse, width=1)
        for y in range(0, g, self.daxiao):
            hua.line([(0,y),(k,y)], fill=self.yanse, width=1)
        if self.zuobiao:
            z = self.yanse[:3] + (255,)
            hua.line([(0, g//2), (k, g//2)], fill=z, width=2)
            hua.line([(k//2, 0), (k//2, g)], fill=z, width=2)
        return Image.alpha_composite(tuxiang, ceng)


def zhuce(shangxiawen):
    return Wangge(shangxiawen)