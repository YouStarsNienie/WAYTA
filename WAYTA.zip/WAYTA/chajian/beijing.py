# -*- coding: utf-8 -*-
"""背景层插件：透明/纯色/自定义图像背景"""

import os
from PIL import Image

class Beijing:
    def __init__(self, shangxiawen):
        self.ctx = shangxiawen
        self.lujing = shangxiawen["lujing"]
        self.peizhi = shangxiawen["peizhi"]
        
        # 读取 peizhi/huabu.txt 的 [beijing] 节
        self.moshi = self.peizhi.qu("huabu", "beijing", "moshi", "chunse") # chunse(纯色) / touming(透明) / tuxiang(图像)
        self.yanse = self.peizhi.qu_yanse("huabu", "beijing", "yanse", (255, 255, 255, 255))
        self.tupian_lujing = self.peizhi.qu("huabu", "beijing", "tupian_lujing", "")
        self._huancun_tu = None  # 缓存图像，避免每次都读盘

    def huoqu_beijing_tu(self, kuan, gao):
        """根据画布尺寸，生成一张背景图"""
        if self.moshi == "touming":
            return Image.new("RGBA", (kuan, gao), (0, 0, 0, 0))
        
        if self.moshi == "tuxiang" and self.tupian_lujing and os.path.exists(self.tupian_lujing):
            if self._huancun_tu is None:
                self._huancun_tu = Image.open(self.tupian_lujing).convert("RGBA")
            # 拉伸到画布大小（或者你也可以改成居中等比例缩放）
            return self._huancun_tu.resize((kuan, gao), Image.LANCZOS)
        
        # 默认纯色
        return Image.new("RGBA", (kuan, gao), self.yanse)

    def gai_moshi(self, xin_moshi):
        """切换背景模式：chunse / touming / tuxiang"""
        if xin_moshi in ("chunse", "touming", "tuxiang"):
            self.moshi = xin_moshi
            self._huancun_tu = None

    def gai_yanse(self, xin_yanse):
        self.yanse = xin_yanse
        self.moshi = "chunse"

    def gai_tupian(self, xin_lujing):
        if os.path.exists(xin_lujing):
            self.tupian_lujing = xin_lujing
            self.moshi = "tuxiang"
            self._huancun_tu = None


def zhuce(shangxiawen):
    return Beijing(shangxiawen)