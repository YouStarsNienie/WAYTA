[app]
title = WAYTA绘图工作台
package.name = wayta
package.domain = org.wayta

# 代码入口
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,txt,json
source.exclude_dirs = .huancun, shuchu, ziyuan/tubiao

version = 0.1.0

# 依赖：Python3, Kivy, Pillow
requirements = python3,kivy,pillow
icon.filename = %(source.dir)s/ziyuan/tubiao/ WAYTA启动器图标(48*48).png
orientation = landscape
fullscreen = 0

# 安卓权限：读写外部存储
android.permissions = WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE,MANAGE_EXTERNAL_STORAGE

android.api = 33
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True